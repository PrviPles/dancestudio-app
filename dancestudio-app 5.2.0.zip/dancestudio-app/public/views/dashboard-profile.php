<?php
/**
 * Student Dashboard -> Profile Tab
 * UPDATED: Includes a conditional notice for new users to claim their profile.
 *
 * @package DanceStudioApp
 */
if(!defined('WPINC')){die;}
$current_user_id = get_current_user_id();
$user_data = get_userdata($current_user_id);

// Get user meta
$phone = get_user_meta($current_user_id, '_dsa_user_phone', true);
$birthday = get_user_meta($current_user_id, '_dsa_user_birth_date', true);
$settings_page_url = add_query_arg('tab', 'settings', get_permalink());

// --- ADDED: Check if this user has any history. If not, they might need to claim a profile. ---
// This is an efficient way to check for any past activity.
$enrollments = get_posts([
    'post_type' => 'dsa_enroll_record',
    'author' => $current_user_id,
    'posts_per_page' => 1,
    'fields' => 'ids'
]);
$show_claim_notice = empty($enrollments);
?>
<div class="dsa-profile-page dsa-profile-view">

    <?php if ($show_claim_notice) : ?>
        <div class="dsa-notice dsa-notice-info" style="padding: 15px; border: 1px solid #ccd0d4; margin-bottom: 20px; background: #f6f7f7;">
            <p style="margin-top: 0;"><strong><?php esc_html_e('Welcome!', 'dancestudio-app'); ?></strong></p>
            <p><?php esc_html_e('If you have an invitation code from the studio, you can link to your existing records to see your full class history and packages.', 'dancestudio-app'); ?></p>
            <p style="margin-bottom: 0;"><a href="<?php echo esc_url(home_url('/claim-profile/')); ?>" class="dsa-button"><?php esc_html_e('Claim Your Profile Here', 'dancestudio-app'); ?></a></p>
        </div>
    <?php endif; ?>

    <div class="dsa-profile-header" style="display:flex;align-items:center;margin-bottom:20px;gap:20px;flex-wrap:wrap;">
        <div class="dsa-profile-avatar">
            <?php echo get_avatar($current_user_id, 150); ?>
        </div>
        <div class="dsa-profile-header-info">
            <h2><?php echo esc_html($user_data->display_name);?></h2>
        </div>
    </div>
    
    <a href="<?php echo esc_url($settings_page_url);?>" class="dsa-button" style="display:inline-block;margin-bottom:20px;"><?php esc_html_e('Edit Profile & Settings','dancestudio-app');?></a>
    <hr>
    
    <h3><?php esc_html_e('Your Information','dancestudio-app');?></h3>
    <p><strong><?php esc_html_e('First Name:','dancestudio-app');?></strong> <?php echo esc_html($user_data->first_name);?></p>
    <p><strong><?php esc_html_e('Last Name:','dancestudio-app');?></strong> <?php echo esc_html($user_data->last_name);?></p>
    <p><strong><?php esc_html_e('Email Address:','dancestudio-app');?></strong> <?php echo esc_html($user_data->user_email);?></p>
    <p><strong><?php esc_html_e('Mobile Phone:','dancestudio-app');?></strong> <?php echo esc_html($phone?:__('Not provided','dancestudio-app'));?></p>
    <p><strong><?php esc_html_e('Birthday:','dancestudio-app');?></strong> <?php echo $birthday?esc_html(date_i18n(get_option('date_format'),strtotime($birthday))):__('Not provided','dancestudio-app');?></p>
</div>