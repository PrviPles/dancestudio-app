<?php
/**
 * General Helper Functions
 * UPDATED: Added subscription trigger logic to the main class save function.
 * @package DanceStudioApp
 */
if ( ! defined( 'WPINC' ) ) die;

/**
 * SAVE FUNCTION
 * This function now handles all meta saving for the 'dsa_group_class' post type.
 */
add_action( 'post_updated', 'dsa_save_class_meta_on_update', 10, 3 );
function dsa_save_class_meta_on_update( $post_id, $post_after, $post_before ) {
    // This hook runs for all post types, so we check for our nonce and post type first.
    if ( ! isset( $_POST['dsa_class_meta_nonce'] ) || ! wp_verify_nonce( $_POST['dsa_class_meta_nonce'], 'dsa_save_class_meta_action' ) ) return;
    if ( 'dsa_group_class' !== $post_after->post_type ) return;

    // Standard WordPress security checks
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    // Save the class detail fields
    $fields_to_save = [
        '_dsa_class_date' => 'dsa_class_date',
        '_dsa_class_start_time' => 'dsa_class_start_time',
        '_dsa_class_end_time' => 'dsa_class_end_time',
        '_dsa_class_group_id' => 'dsa_class_group_id'
    ];
    foreach($fields_to_save as $meta_key => $post_key) {
        if (isset($_POST[$post_key])) {
            $value = str_contains($meta_key, '_id') ? absint($_POST[$post_key]) : sanitize_text_field($_POST[$post_key]);
            update_post_meta($post_id, $meta_key, $value);
        }
    }

    if ( isset($_POST['dsa_class_notes']) && $post_before->post_content !== $_POST['dsa_class_notes'] ) {
        // Use wp_update_post to save to post_content to avoid triggering this hook again in a loop
        wp_update_post(['ID' => $post_id, 'post_content' => sanitize_textarea_field($_POST['dsa_class_notes'])]);
    }

    // Save the practiced choreographies
    if ( ! empty($_POST['dsa_choreographies']) && is_array($_POST['dsa_choreographies']) ) {
        $sanitized_ids = array_map('absint', array_keys($_POST['dsa_choreographies']));
        update_post_meta($post_id, '_dsa_practiced_choreography_ids', $sanitized_ids);
    } else {
        delete_post_meta($post_id, '_dsa_practiced_choreography_ids');
    }

    // --- START: REPLACEMENT CODE ---
    // Save attendance data and apply subscription logic
    if ( isset( $_POST['dsa_attendance'] ) && is_array( $_POST['dsa_attendance'] ) ) {
        $group_id = get_post_meta($post_id, '_dsa_class_group_id', true);
        $class_date = get_post_meta($post_id, '_dsa_class_date', true);

        // We need the state of attendance *before* this save to correctly decrement the counter if a status is changed.
        $previous_attendance = get_post_meta($post_id, '_dsa_class_attendance', true);
        if (!is_array($previous_attendance)) $previous_attendance = [];

        $sanitized_attendance = [];
        $allowed_statuses = ['present', 'absent', 'incomplete', 'excused'];
        $statuses_that_count = ['present', 'incomplete'];

        foreach ( $_POST['dsa_attendance'] as $student_id => $data ) {
            $sane_id = absint($student_id);
            if ( $sane_id > 0 && isset($data['status']) ) {
                $status = sanitize_key($data['status']);
                $new_status = in_array($status, $allowed_statuses) ? $status : 'absent';

                $sanitized_attendance[$sane_id] = [
                    'status'  => $new_status,
                    'remarks' => isset($data['remarks']) ? sanitize_text_field($data['remarks']) : '',
                ];

                $enrollment_record_id = dsa_get_active_enrollment_record($sane_id, $group_id);
                if ( !$enrollment_record_id ) {
                    continue; // Skip if student isn't enrolled
                }

                $previous_status = $previous_attendance[$sane_id]['status'] ?? 'absent';
                $new_status_counts = in_array($new_status, $statuses_that_count);
                $previous_status_counted = in_array($previous_status, $statuses_that_count);

                // Get the current lesson count
                $lesson_count = (int) get_post_meta($enrollment_record_id, '_dsa_lessons_attended_count', true);

                // Case 1: Status changed FROM counting TO NOT counting (e.g., Present -> Excused)
                if ( $previous_status_counted && !$new_status_counts ) {
                    update_post_meta($enrollment_record_id, '_dsa_lessons_attended_count', $lesson_count - 1);
                }
                // Case 2: Status changed FROM NOT counting TO counting (e.g., Absent -> Present)
                elseif ( !$previous_status_counted && $new_status_counts ) {
                    update_post_meta($enrollment_record_id, '_dsa_lessons_attended_count', $lesson_count + 1);

                    // "First Attendance" Trigger: Also set the start date if this is the first counted attendance
                    $start_date = get_post_meta($enrollment_record_id, '_dsa_subscription_start_date', true);
                    if ( empty($start_date) ) {
                        update_post_meta($enrollment_record_id, '_dsa_subscription_start_date', $class_date);
                    }
                }
                // Case 3: Status remains the same or changes between two counting statuses (no change to count)
                // Do nothing to the counter.
            }
        }
        update_post_meta( $post_id, '_dsa_class_attendance', $sanitized_attendance );
    }
    // --- END: REPLACEMENT CODE ---
}


// --- All other existing helper functions below ---

if(!function_exists('dsa_get_partner_id')){
    function dsa_get_partner_id($user_id){
        $partner_id=get_user_meta($user_id,'dsa_partner_user_id',true);
        return $partner_id?absint($partner_id):false;
    }
}

if(!function_exists('dsa_calculate_age')){
    function dsa_calculate_age($birth_date){
        if(!$birth_date)return null;
        try{
            $birthDate=new DateTime($birth_date);
            $today=new DateTime('today');
            return $birthDate->diff($today)->y;
        }catch(Exception $e){
            return null;
        }
    }
}

if(!function_exists('dsa_get_lesson_end_time')){
    function dsa_get_lesson_end_time($date_string,$time_string,$duration_minutes=45){
        if(!$date_string||!$time_string)return false;
        try{
            $start_datetime=new DateTime($date_string.' '.$time_string);
            $start_datetime->add(new DateInterval('PT'.(int)$duration_minutes.'M'));
            return $start_datetime->format('H:i');
        }catch(Exception $e){
            return false;
        }
    }
}

if ( ! function_exists('dsa_render_sortable_table_header') ) {
    function dsa_render_sortable_table_header( $label, $orderby_key, $current_orderby, $current_order ) {
        $order_for_link = ($current_orderby === $orderby_key && strtolower($current_order) === 'asc') ? 'desc' : 'asc';
        $css_class = 'manage-column';
        if ($current_orderby === $orderby_key) {
            $css_class .= ' sorted ' . strtolower($current_order);
        } else {
            $css_class .= ' sortable desc';
        }
        $link = add_query_arg(['orderby' => $orderby_key, 'order' => $order_for_link]);
        echo '<th scope="col" class="' . esc_attr($css_class) . '"><a href="' . esc_url($link) . '"><span>' . esc_html($label) . '</span><span class="sorting-indicator"></span></a></th>';
    }
}

function dsa_generate_hub3a_barcode_string( $order, $studio_settings ) {
    $lines = [];
    $lines[] = "HRVHUB30";
    $lines[] = "HRK";
    $amount_in_cents = number_format($order->get_total(), 2, '', '');
    $lines[] = str_pad($amount_in_cents, 15, '0', STR_PAD_LEFT);
    $lines[] = strtoupper(substr($order->get_formatted_billing_full_name(), 0, 25));
    $lines[] = strtoupper(substr($order->get_billing_address_1(), 0, 25));
    $lines[] = strtoupper(substr($order->get_billing_city(), 0, 25));
    $lines[] = strtoupper(!empty($studio_settings['studio_name']) ? substr($studio_settings['studio_name'], 0, 25) : '');
    $lines[] = strtoupper(!empty($studio_settings['street_address']) ? substr($studio_settings['street_address'], 0, 25) : '');
    $lines[] = strtoupper(!empty($studio_settings['zip_code']) && !empty($studio_settings['city']) ? substr($studio_settings['zip_code'] . ' ' . $studio_settings['city'], 0, 25) : '');
    $lines[] = !empty($studio_settings['iban']) ? str_replace(' ', '', $studio_settings['iban']) : '';
    $lines[] = "HR99";
    $lines[] = "UPLATA-" . $order->get_order_number();
    $lines[] = "UPLATA ZA PLESNI TECAJ";
    return implode("\n", $lines);
}

function dsa_get_couple_package_progress( $user1_id, $user2_id ) {
    if ( ! class_exists('WooCommerce') ) return 'N/A';
    $orders_query = new WC_Order_Query(['limit' => 1, 'customer' => [$user1_id, $user2_id], 'status' => ['processing', 'completed'], 'orderby' => 'date', 'order' => 'DESC']);
    $orders = $orders_query->get_orders();
    if ( empty($orders) ) return 'No Package';
    $latest_order = reset($orders);
    $order_id = $latest_order->get_id();
    $lessons_in_package = 0;
    foreach ( $latest_order->get_items() as $item ) {
        $product_id = $item->get_product_id();
        if ( has_term( 'lesson-packages', 'product_cat', $product_id ) ) {
            $lessons_in_package = (int) get_post_meta($product_id, '_dsa_lessons_in_package', true);
            break;
        }
    }
    if ( $lessons_in_package === 0 ) return 'N/A';
    $lessons_used_query = new WP_Query(['post_type' => 'dsa_private_lesson', 'posts_per_page' => -1, 'meta_key' => '_dsa_lesson_order_id', 'meta_value' => $order_id, 'fields' => 'ids']);
    $lessons_used_count = $lessons_used_query->found_posts;
    $percentage = round( ($lessons_used_count / $lessons_in_package) * 100 );
    return sprintf( '%d / %d (%d%%)', $lessons_used_count, $lessons_in_package, $percentage );
}

add_filter('set-screen-option', function ($status, $option, $value) {
    if ('students_per_page' === $option) return $value;
    return $status;
}, 10, 3);

add_action('admin_head', function() {
    $screen = get_current_screen();
    if ($screen && $screen->id === 'dancestudio-app_page_dsa-all-students') {
        add_screen_option('per_page', [
            'label'   => __('Students per page', 'dancestudio-app'),
            'default' => 20,
            'option'  => 'students_per_page',
        ]);
    }
});