<?php
/**
 * View: Renders the Student Subscriptions report page using WP_List_Table.
 * This version includes sorting, filtering, search, and pagination.
 * @package DanceStudioApp
 */
if ( ! defined( 'WPINC' ) ) die;

if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

/**
 * Creates the List Table for the Subscriptions Report.
 */
class DSA_Subscriptions_List_Table extends WP_List_Table {

    public function __construct() {
        parent::__construct( [
            'singular' => __( 'Subscription', 'dancestudio-app' ),
            'plural'   => __( 'Subscriptions', 'dancestudio-app' ),
            'ajax'     => false
        ] );
    }

    /**
     * Define the columns that will be displayed.
     * @return array
     */
    public function get_columns() {
        return [
            'student_name'    => __( 'Student Name', 'dancestudio-app' ),
            'enrolled_group'  => __( 'Enrolled Group', 'dancestudio-app' ),
            'lessons_used'    => __( 'Lessons Used', 'dancestudio-app' ),
            'payment_status'  => __( 'Payment Status', 'dancestudio-app' ),
            'linked_order'    => __( 'Linked Order', 'dancestudio-app' ),
            'actions'         => __( 'Actions', 'dancestudio-app' ),
        ];
    }

    /**
     * Define which columns are sortable.
     * @return array
     */
    public function get_sortable_columns() {
        return [
            'student_name'   => ['student_name', false],
            'enrolled_group' => ['enrolled_group', false],
        ];
    }

    /**
     * Handles the rendering of the Group filter dropdown.
     */
    protected function extra_tablenav( $which ) {
        if ( 'top' === $which ) {
            $current_group = isset($_REQUEST['group_filter']) ? absint($_REQUEST['group_filter']) : 0;
            $all_groups = get_posts(['post_type' => 'dsa_group', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC']);
            
            echo '<div class="alignleft actions">';
            echo '<label for="filter-by-group" class="screen-reader-text">' . __('Filter by group') . '</label>';
            echo '<select name="group_filter" id="filter-by-group">';
            echo '<option value="0">' . __('All groups') . '</option>';
            if ($all_groups) {
                foreach ($all_groups as $group) {
                    echo '<option value="' . esc_attr($group->ID) . '"' . selected($current_group, $group->ID, false) . '>' . esc_html($group->post_title) . '</option>';
                }
            }
            echo '</select>';
            submit_button(__('Filter'), '', 'filter_action', false, ['id' => 'post-query-submit']);
            echo '</div>';
        }
    }

    /**
     * Prepare the items for the table to process.
     */
    public function prepare_items() {
        $this->_column_headers = [$this->get_columns(), [], $this->get_sortable_columns()];

        $per_page     = $this->get_items_per_page( 'subscriptions_per_page', 20 );
        $current_page = $this->get_pagenum();
        
        $query_args = [
            'post_type'      => 'dsa_enroll_record',
            'post_status'    => 'publish',
            'posts_per_page' => -1, // Get all records to sort by name in PHP
        ];

        // Filtering
        if ( ! empty( $_REQUEST['group_filter'] ) ) {
            $query_args['post_parent'] = absint( $_REQUEST['group_filter'] );
        }

        // Searching
        if ( ! empty( $_REQUEST['s'] ) ) {
            $search_term = sanitize_text_field( $_REQUEST['s'] );
            $user_query = new WP_User_Query([
                'search'         => '*' . $search_term . '*',
                'search_columns' => ['display_name', 'user_login'],
                'fields'         => 'ID',
            ]);
            $student_ids = $user_query->get_results();
            if (!empty($student_ids)) {
                $query_args['author__in'] = $student_ids;
            } else {
                $query_args['author__in'] = [0]; // No users found, so return no results
            }
        }
        
        $enrollments = get_posts($query_args);
        $table_data = [];

        foreach ($enrollments as $record) {
            $student_data = get_userdata($record->post_author);
            if (!$student_data) continue;

            $table_data[] = [
                'ID'             => $record->ID,
                'student_id'     => $record->post_author,
                'group_id'       => $record->post_parent,
                'student_name'   => $student_data->display_name,
                'enrolled_group' => get_the_title($record->post_parent),
            ];
        }

        // Sorting
        $orderby = isset( $_REQUEST['orderby'] ) ? sanitize_key( $_REQUEST['orderby'] ) : 'student_name';
        $order   = isset( $_REQUEST['order'] ) ? sanitize_key( $_REQUEST['order'] ) : 'asc';
        usort( $table_data, function ( $a, $b ) use ( $orderby, $order ) {
            $result = strnatcasecmp( $a[$orderby], $b[$orderby] );
            return ( 'asc' === $order ) ? $result : -$result;
        } );

        $total_items = count($table_data);
        $this->items = array_slice($table_data, (($current_page - 1) * $per_page), $per_page);

        $this->set_pagination_args( [
            'total_items' => $total_items,
            'per_page'    => $per_page
        ] );
    }

    /**
     * Default column rendering.
     */
    public function column_default( $item, $column_name ) {
        $lesson_count = (int) get_post_meta($item['ID'], '_dsa_lessons_attended_count', true);
        $order_id     = get_post_meta($item['ID'], '_dsa_current_subscription_order_id', true);

        switch ( $column_name ) {
            case 'lessons_used':
                return '<strong>' . esc_html($lesson_count) . ' / 8</strong>';
            
            case 'payment_status':
                $is_paid = ( $lesson_count === 0 && !empty($order_id) );
                $status = $is_paid ? __('Paid', 'dancestudio-app') : __('Due for Renewal', 'dancestudio-app');
                $color = $is_paid ? 'green' : 'red';
                return '<span style="color:' . esc_attr($color) . '; font-weight: bold;">' . esc_html($status) . '</span>';
            
            case 'linked_order':
                if (!empty($order_id)) {
                    return '<a href="' . esc_url(get_edit_post_link($order_id)) . '" target="_blank">#' . esc_html($order_id) . '</a>';
                }
                return '<em>' . __('N/A', 'dancestudio-app') . '</em>';
            
            case 'actions':
                $is_paid = ( $lesson_count === 0 && !empty($order_id) );
                if (!$is_paid) {
                    return sprintf(
                        '<button type="button" class="button button-primary dsa-send-payment-link-button" data-enrollment-id="%s">%s<span class="spinner"></span></button>',
                        esc_attr($item['ID']),
                        esc_html__('Send Payment Link', 'dancestudio-app')
                    );
                }
                return '';

            default:
                return '';
        }
    }

    /**
     * Renders the student name column with a link.
     */
    public function column_student_name($item) {
        $link = get_edit_user_link($item['student_id']);
        return '<strong><a href="' . esc_url($link) . '">' . esc_html($item['student_name']) . '</a></strong>';
    }

    /**
     * Renders the group name column with a link.
     */
    public function column_enrolled_group($item) {
        $link = get_edit_post_link($item['group_id']);
        return '<a href="' . esc_url($link) . '">' . esc_html($item['enrolled_group']) . '</a>';
    }
}


/**
 * Main function to render the Subscriptions report page.
 */
function dsa_render_subscriptions_report_page() {
    $subscriptions_table = new DSA_Subscriptions_List_Table();
    ?>
    <h3><?php esc_html_e( 'Student Subscription Status', 'dancestudio-app' ); ?></h3>
    <p><?php esc_html_e( 'This report tracks the 8-lesson subscription cycle for each student in their respective groups.', 'dancestudio-app' ); ?></p>
    <div id="dsa-admin-notices"></div>

    <form method="get">
        <input type="hidden" name="page" value="<?php echo esc_attr( $_REQUEST['page'] ); ?>" />
        <?php
        $subscriptions_table->prepare_items();
        $subscriptions_table->search_box('Search Students', 'student');
        $subscriptions_table->display();
        ?>
    </form>
    
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $('.wp-list-table').on('click', '.dsa-send-payment-link-button', function() {
                var button = $(this);
                var spinner = button.find('.spinner');
                var enrollmentId = button.data('enrollment-id');

                button.prop('disabled', true);
                spinner.addClass('is-active');
                
                $.post(ajaxurl, {
                    action: 'dsa_send_payment_link',
                    nonce: '<?php echo wp_create_nonce("dsa_send_payment_link_nonce"); ?>',
                    enrollment_id: enrollmentId
                })
                .done(function(response) {
                    var noticeClass = response.success ? 'notice-success' : 'notice-error';
                    var message = response.data.message || 'An unknown error occurred.';
                    $('#dsa-admin-notices').html('<div class="notice ' + noticeClass + ' is-dismissible"><p>' + message + '</p></div>').show();
                    $('html, body').animate({ scrollTop: 0 }, 'slow');
                })
                .fail(function() {
                    $('#dsa-admin-notices').html('<div class="notice notice-error is-dismissible"><p>A server error occurred.</p></div>').show();
                    $('html, body').animate({ scrollTop: 0 }, 'slow');
                })
                .always(function() {
                    button.prop('disabled', false);
                    spinner.removeClass('is-active');
                });
            });
        });
    </script>
    <?php
}