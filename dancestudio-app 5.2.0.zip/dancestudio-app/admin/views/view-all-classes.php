<?php
/**
 * View: All Group Classes List Page
 * NOW INCLUDES pagination and filters for Group and Teacher.
 *
 * @package DanceStudioApp
 */

if ( ! defined( 'WPINC' ) ) {
    die;
}

if ( ! function_exists( 'dsa_render_all_classes_page' ) ) {
    function dsa_render_all_classes_page() {
        // --- 1. Get filter and pagination parameters from the URL ---
        $paged          = isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1;
        $group_filter   = isset( $_GET['group_filter'] ) ? absint( $_GET['group_filter'] ) : 0;
        $teacher_filter = isset( $_GET['teacher_filter'] ) ? absint( $_GET['teacher_filter'] ) : 0;
        $orderby        = isset( $_GET['orderby'] ) ? sanitize_key( $_GET['orderby'] ) : 'class_date';
        $order          = ( isset( $_GET['order'] ) && strtolower( $_GET['order'] ) === 'asc' ) ? 'ASC' : 'DESC';
        
        $query_args = [
            'post_type'      => 'dsa_group_class',
            'posts_per_page' => 20, // Items per page
            'paged'          => $paged,
            'order'          => $order,
            'meta_query'     => [
                'relation' => 'AND',
            ],
        ];

        // --- 2. Build the query based on the active filters ---
        if ( 'title' === $orderby ) {
            $query_args['orderby'] = 'title';
        } else {
            $query_args['orderby'] = 'meta_value';
            $query_args['meta_key'] = '_dsa_class_date';
        }

        if ( $group_filter > 0 ) {
            $query_args['meta_query'][] = [
                'key'   => '_dsa_class_group_id',
                'value' => $group_filter,
            ];
        }

        if ( $teacher_filter > 0 ) {
            $query_args['meta_query'][] = [
                'key'   => '_dsa_primary_teacher_id',
                'value' => $teacher_filter,
            ];
        }
        
        $classes_query = new WP_Query($query_args);
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'All Group Classes', 'dancestudio-app' ); ?></h1>

            <form method="get" class="dsa-filters-form">
                <input type="hidden" name="page" value="dsa-all-classes">
                <div class="tablenav top">
                    <div class="alignleft actions">
                        <label for="group_filter" class="screen-reader-text"><?php _e('Filter by Group'); ?></label>
                        <select name="group_filter" id="group_filter">
                            <option value="0"><?php _e('All Groups'); ?></option>
                            <?php
                            $groups = get_posts(['post_type' => 'dsa_group', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC']);
                            foreach ($groups as $group) {
                                echo '<option value="' . esc_attr($group->ID) . '"' . selected($group_filter, $group->ID, false) . '>' . esc_html($group->post_title) . '</option>';
                            }
                            ?>
                        </select>

                        <label for="teacher_filter" class="screen-reader-text"><?php _e('Filter by Teacher'); ?></label>
                        <?php
                        wp_dropdown_users([
                            'name'             => 'teacher_filter',
                            'id'               => 'teacher_filter',
                            'role__in'         => ['teacher', 'studio_manager', 'administrator'],
                            'show_option_none' => __('All Teachers', 'dancestudio-app'),
                            'option_none_value'=> '0',
                            'selected'         => $teacher_filter,
                        ]);
                        ?>
                        <input type="submit" id="post-query-submit" class="button" value="<?php esc_attr_e('Filter'); ?>">
                    </div>
                     <?php
                    $total_pages = $classes_query->max_num_pages;
                    if ($total_pages > 1) {
                        $current_page = max(1, $paged);
                        echo '<div class="tablenav-pages"><span class="displaying-num">' . $classes_query->found_posts . ' items</span>';
                        echo paginate_links([
                            'base'      => add_query_arg('paged', '%#%'),
                            'format'    => '',
                            'prev_text' => __('&laquo;'),
                            'next_text' => __('&raquo;'),
                            'total'     => $total_pages,
                            'current'   => $current_page,
                        ]);
                        echo '</div>';
                    }
                    ?>
                </div>

                <table class="wp-list-table widefat fixed striped posts">
                    <thead>
                        <tr>
                            <?php 
                            dsa_render_sortable_table_header( __('Class Title', 'dancestudio-app'), 'title', $orderby, $order ); 
                            dsa_render_sortable_table_header( __('Date', 'dancestudio-app'), 'class_date', $orderby, $order );
                            ?>
                            <th scope="col"><?php esc_html_e('Time', 'dancestudio-app'); ?></th>
                            <th scope="col"><?php esc_html_e('Group', 'dancestudio-app'); ?></th>
                            <th scope="col"><?php esc_html_e('Teacher', 'dancestudio-app'); ?></th>
                        </tr>
                    </thead>
                    <tbody id="the-list">
                        <?php
                        if ( $classes_query->have_posts() ) :
                            while ( $classes_query->have_posts() ) : $classes_query->the_post();
                                $class_id = get_the_ID();
                                $class_date = get_post_meta( $class_id, '_dsa_class_date', true );
                                $start_time = get_post_meta( $class_id, '_dsa_class_start_time', true );
                                $end_time = get_post_meta( $class_id, '_dsa_class_end_time', true );
                                $group_id = get_post_meta( $class_id, '_dsa_class_group_id', true );
                                $teacher_id = get_post_meta( $class_id, '_dsa_primary_teacher_id', true );
                                $group_name = $group_id ? get_the_title( $group_id ) : __('N/A', 'dancestudio-app');
                                $teacher_name = $teacher_id ? get_the_author_meta('display_name', $teacher_id) : '—';
                                $time_display = $start_time ? date_i18n(get_option('time_format'), strtotime($start_time)) : '';
                                if ($end_time) {
                                    $time_display .= ' - ' . date_i18n(get_option('time_format'), strtotime($end_time));
                                }
                                ?>
                                <tr id="post-<?php echo esc_attr($class_id); ?>">
                                    <td class="title column-title has-row-actions column-primary" data-colname="<?php esc_attr_e('Class Title','dancestudio-app'); ?>">
                                        <strong><a class="row-title" href="<?php echo esc_url(get_edit_post_link($class_id)); ?>"><?php the_title(); ?></a></strong>
                                        <div class="row-actions"><span class="edit"><a href="<?php echo esc_url(get_edit_post_link($class_id)); ?>"><?php esc_html_e('Edit & Attendance','dancestudio-app');?></a> | </span><span class="trash"><a href="<?php echo esc_url(get_delete_post_link($class_id, '', true)); ?>" class="submitdelete" onclick="return confirm('<?php echo esc_js(__('Are you sure you want to delete this class?','dancestudio-app'));?>');"><?php esc_html_e('Delete Permanently','dancestudio-app');?></a></span></div>
                                    </td>
                                    <td data-colname="<?php esc_attr_e('Date','dancestudio-app');?>"><?php echo $class_date ? esc_html(date_i18n(get_option('date_format'), strtotime($class_date))) : ''; ?></td>
                                    <td data-colname="<?php esc_attr_e('Time','dancestudio-app');?>"><?php echo esc_html($time_display); ?></td>
                                    <td data-colname="<?php esc_attr_e('Group','dancestudio-app');?>"><?php echo esc_html($group_name); ?></td>
                                    <td data-colname="<?php esc_attr_e('Teacher','dancestudio-app');?>"><?php echo esc_html($teacher_name); ?></td>
                                </tr>
                                <?php
                            endwhile;
                            wp_reset_postdata();
                        else: ?>
                            <tr class="no-items"><td class="colspanchange" colspan="5"><?php esc_html_e('No group classes found matching your criteria.', 'dancestudio-app'); ?></td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </form>
        </div>
        <?php
    }
}