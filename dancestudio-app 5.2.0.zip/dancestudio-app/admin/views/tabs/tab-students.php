<?php
/**
 * View: Renders the ENTIRE "Students" tab, including the list of students 
 * and the single student profile view with all its sub-tabs.
 * @package DanceStudioApp
 */
if ( ! defined( 'WPINC' ) ) die;

/**
 * Main router for the Students tab.
 */
if ( ! function_exists( 'dsa_render_students_tab' ) ) {
    function dsa_render_students_tab() {
        if ( isset( $_GET['action'] ) && $_GET['action'] === 'view_profile' && isset( $_GET['student_id'] ) ) {
            dsa_render_single_student_profile_page( absint( $_GET['student_id'] ) );
        } else {
            dsa_render_all_students_list_page();
        }
    }
}

/**
 * Renders the list of all students with sorting, filtering, and searching.
 */
if ( ! function_exists( 'dsa_render_all_students_list_page' ) ) {
    function dsa_render_all_students_list_page() {
        $orderby      = isset( $_GET['orderby'] ) ? sanitize_key( $_GET['orderby'] ) : 'last_name';
        $order        = ( isset( $_GET['order'] ) && in_array( strtolower( $_GET['order'] ), ['asc', 'desc'] ) ) ? strtoupper( $_GET['order'] ) : 'ASC';
        $group_filter = isset( $_GET['group_filter'] ) ? absint( $_GET['group_filter'] ) : 0;
        $search_term  = isset( $_GET['s'] ) ? sanitize_text_field( $_GET['s'] ) : '';
        $per_page     = 20;
        $current_page = isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1;

        $query_args = [
            'role__in'    => ['student', 'subscriber'],
            'orderby'     => $orderby,
            'order'       => $order,
            'number'      => $per_page,
            'paged'       => $current_page,
            'count_total' => true,
            'fields'      => 'ID',
        ];

        if ( ! empty( $search_term ) ) {
            $query_args['search'] = '*' . $search_term . '*';
            $query_args['search_columns'] = ['user_login', 'user_email', 'display_name'];
        }

        if ( $group_filter > 0 ) {
            $enrollment_records = get_posts([
                'post_type'      => 'dsa_enroll_record', 'post_status'    => 'publish',
                'post_parent'    => $group_filter, 'posts_per_page' => -1,
            ]);
            $enrolled_student_ids = wp_list_pluck( $enrollment_records, 'post_author' );
            $query_args['include'] = !empty($enrolled_student_ids) ? array_unique($enrolled_student_ids) : [0];
        }

        $students_query = new WP_User_Query($query_args);
        $student_ids = $students_query->get_results();
        $total_students = $students_query->get_total();
        ?>
        <style>.dsa-table-responsive-wrapper { width: 100%; overflow-x: auto; }</style>
        <h3><?php esc_html_e( 'All Students', 'dancestudio-app' ); ?></h3>
        <form method="get">
            <input type="hidden" name="page" value="dsa-students-tab">
            <p class="search-box">
                <label class="screen-reader-text" for="dsa-student-search-input"><?php _e('Search Students:'); ?></label>
                <input type="search" id="dsa-student-search-input" name="s" value="<?php echo esc_attr($search_term); ?>">
                <input type="submit" id="search-submit" class="button" value="<?php esc_attr_e('Search Students'); ?>">
            </p>
            <div class="tablenav top">
                <div class="alignleft actions bulkactions">
                    <select name="group_filter">
                        <option value="0"><?php _e('All Groups');?></option>
                        <?php
                        $groups = get_posts(['post_type' => 'dsa_group', 'posts_per_page' => -1]);
                        foreach ($groups as $group) {
                            echo '<option value="' . esc_attr($group->ID) . '" ' . selected($group_filter, $group->ID, false) . '>' . esc_html($group->post_title) . '</option>';
                        }
                        ?>
                    </select>
                    <input type="submit" class="button" value="<?php _e('Filter');?>">
                    <a href="<?php echo esc_url(admin_url('user-new.php')); ?>" class="button button-primary"><?php esc_html_e('Add New Student', 'dancestudio-app'); ?></a>
                </div>
                <div class="tablenav-pages">
                    <span class="displaying-num"><?php echo esc_html($total_students); ?> students</span>
                    <?php
                    $total_pages = ceil($total_students / $per_page);
                    if ($total_pages > 1) {
                        echo paginate_links([
                            'base' => add_query_arg('paged', '%#%'), 'format' => '','prev_text' => __('&laquo;'), 'next_text' => __('&raquo;'),
                            'total' => $total_pages, 'current' => $current_page
                        ]);
                    }
                    ?>
                </div>
            </div>
            <div class="dsa-table-responsive-wrapper">
                <table class="wp-list-table widefat fixed striped users">
                    <thead>
                        <tr>
                            <th scope="col" class="manage-column" style="width: 50px;">#</th>
                            <?php
                            dsa_render_sortable_table_header( __('First Name', 'dancestudio-app'), 'first_name', $orderby, $order );
                            dsa_render_sortable_table_header( __('Last Name', 'dancestudio-app'), 'last_name', $orderby, $order );
                            ?>
                            <th scope="col"><?php esc_html_e('Enrolled In Group(s)', 'dancestudio-app'); ?></th>
                            <th scope="col"><?php esc_html_e('Discount', 'dancestudio-app'); ?></th>
                            <th scope="col"><?php esc_html_e('Actions', 'dancestudio-app'); ?></th>
                        </tr>
                    </thead>
                    <tbody id="the-list">
                        <?php if ( ! empty( $student_ids ) ) :
                            $row_number = ( ($current_page - 1) * $per_page ) + 1;
                            foreach ( $student_ids as $student_id ) :
                                $student = get_userdata( $student_id );
                                if (!$student) continue;

                                $profile_link = admin_url('admin.php?page=dsa-students-tab&action=view_profile&student_id=' . $student->ID);
                                $enrolled_groups = [];
                                $enrollment_records = get_posts(['post_type' => 'dsa_enroll_record', 'post_status' => 'publish', 'author' => $student->ID, 'posts_per_page' => -1]);
                                foreach ( $enrollment_records as $record ) { $group_title = get_the_title($record->post_parent); if ($group_title) { $enrolled_groups[] = $group_title; } }

                                $discounts = [];
                                if ( get_user_meta( $student->ID, '_dsa_is_retired', true ) === '1' ) { $discounts[] = __('Retiree', 'dancestudio-app'); }
                                if ( get_user_meta( $student->ID, '_dsa_family_discount', true ) === '1' ) { $discounts[] = __('Family', 'dancestudio-app'); }
                                $discount_display = !empty($discounts) ? implode(', ', $discounts) : '—';
                                ?>
                                <tr>
                                    <td><?php echo $row_number; ?></td>
                                    <td><strong><a href="<?php echo esc_url($profile_link); ?>"><?php echo esc_html($student->first_name); ?></a></strong></td>
                                    <td><strong><a href="<?php echo esc_url($profile_link); ?>"><?php echo esc_html($student->last_name); ?></a></strong></td>
                                    <td><?php echo !empty($enrolled_groups) ? esc_html(implode(', ', $enrolled_groups)) : '—'; ?></td>
                                    <td><?php echo esc_html( $discount_display ); ?></td>
                                    <td>
                                        <a href="<?php echo esc_url($profile_link); ?>" class="button button-secondary"><?php esc_html_e('View Profile', 'dancestudio-app'); ?></a>
                                        <button type="button" class="button button-secondary dsa-edit-enrollments-button" data-student-id="<?php echo esc_attr($student->ID); ?>" data-student-name="<?php echo esc_attr($student->display_name); ?>">
                                            <?php esc_html_e('Edit Enrollment', 'dancestudio-app'); ?>
                                        </button>
                                    </td>
                                </tr>
                                <?php
                                $row_number++;
                            endforeach;
                        else: ?>
                            <tr class="no-items"><td class="colspanchange" colspan="6"><?php esc_html_e('No students found.', 'dancestudio-app'); ?></td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </form>
        <div id="dsa-enrollment-modal" style="display:none;" title="<?php esc_attr_e('Manage Enrollments', 'dancestudio-app'); ?>"><input type="hidden" id="dsa_enroll_student_id" value=""><div class="dsa-modal-content"><p>Loading...</p></div></div>
        <?php
    }
}

/**
 * Renders the shell for the single student profile page.
 */
if ( ! function_exists( 'dsa_render_single_student_profile_page' ) ) {
    function dsa_render_single_student_profile_page( $student_id ) {
        $student_data = get_userdata( $student_id );
        if ( ! $student_data ) {
            echo '<div class="notice notice-error"><p>' . esc_html__('Student not found.', 'dancestudio-app') . '</p></div>';
            return;
        }

        $active_tab = isset($_GET['profile_tab']) ? sanitize_key($_GET['profile_tab']) : 'details';
        $base_url = admin_url('admin.php?page=dsa-students-tab&action=view_profile&student_id=' . $student_id);
        ?>
        <div class="wrap dsa-student-profile">
            <h1 class="wp-heading-inline"><?php echo esc_html( $student_data->display_name ); ?></h1>
            <a href="<?php echo esc_url( get_edit_user_link($student_id) ); ?>" class="page-title-action" target="_blank"><?php esc_html_e('Edit in WordPress', 'dancestudio-app'); ?></a>
            <a href="<?php echo esc_url( admin_url('admin.php?page=dsa-students-tab') ); ?>" class="page-title-action"><?php esc_html_e('← Back to All Students', 'dancestudio-app'); ?></a>
            <hr class="wp-header-end">

            <h2 class="nav-tab-wrapper" style="margin-top: 20px;">
                <a href="<?php echo esc_url(add_query_arg('profile_tab', 'details', $base_url)); ?>" class="nav-tab <?php if($active_tab == 'details') echo 'nav-tab-active'; ?>"><?php _e('Profile Details','dancestudio-app');?></a>
                <a href="<?php echo esc_url(add_query_arg('profile_tab', 'enrollments', $base_url)); ?>" class="nav-tab <?php if($active_tab == 'enrollments') echo 'nav-tab-active'; ?>"><?php _e('Enrollment History','dancestudio-app');?></a>
                <a href="<?php echo esc_url(add_query_arg('profile_tab', 'lessons', $base_url)); ?>" class="nav-tab <?php if($active_tab == 'lessons') echo 'nav-tab-active'; ?>"><?php _e('Private Lessons','dancestudio-app');?></a>
                <a href="<?php echo esc_url(add_query_arg('profile_tab', 'packages', $base_url)); ?>" class="nav-tab <?php if($active_tab == 'packages') echo 'nav-tab-active'; ?>"><?php _e('Packages & Orders','dancestudio-app');?></a>
            </h2>

            <div class="dsa-profile-tab-content" style="margin-top: 20px; background: #fff; padding: 20px; border: 1px solid #ccd0d4; border-top: none;">
                <?php
                switch ($active_tab) {
                    case 'enrollments':
                        if(function_exists('dsa_render_enrollment_history_tab_content')) dsa_render_enrollment_history_tab_content( $student_data );
                        break;
                    case 'lessons':
                        if(function_exists('dsa_render_private_lessons_tab_content')) dsa_render_private_lessons_tab_content( $student_data );
                        break;
                    case 'packages':
                        if(function_exists('dsa_render_packages_orders_tab_content')) dsa_render_packages_orders_tab_content( $student_data );
                        break;
                    case 'details':
                    default:
                        if(function_exists('dsa_render_profile_details_tab_content')) dsa_render_profile_details_tab_content( $student_data );
                        break;
                }
                ?>
            </div>
        </div>
        <?php
    }
}

/**
 * Renders the content for the "Profile Details" tab.
 */
if ( ! function_exists( 'dsa_render_profile_details_tab_content' ) ) {
    function dsa_render_profile_details_tab_content( $student_data ) {
        $student_id = $student_data->ID;
        $phone = get_user_meta($student_id, '_dsa_user_phone', true);
        $birthday = get_user_meta($student_id, '_dsa_user_birth_date', true);
        $age = $birthday && function_exists('dsa_calculate_age') ? dsa_calculate_age($birthday) : '—';
        $partner_id = function_exists('dsa_get_partner_id') ? dsa_get_partner_id($student_id) : false;
        $street = get_user_meta( $student_id, '_dsa_user_street', true ) ?: '—';
        $postal_code = get_user_meta( $student_id, '_dsa_user_postal_code', true ) ?: '—';
        $city = get_user_meta( $student_id, '_dsa_user_city', true ) ?: '—';
        $is_retired = get_user_meta( $student_id, '_dsa_is_retired', true );
        $has_family_discount = get_user_meta( $student_id, '_dsa_family_discount', true );
        ?>
        <div style="display: flex; gap: 30px; flex-wrap: wrap;">
            <div style="flex: 1; min-width: 300px;">
                <h3><?php esc_html_e('Contact Information', 'dancestudio-app'); ?></h3>
                <table class="form-table">
                    <tr><th><?php esc_html_e('First Name', 'dancestudio-app'); ?></th><td id="dsa-view-first-name"><?php echo esc_html($student_data->first_name); ?></td></tr>
                    <tr><th><?php esc_html_e('Last Name', 'dancestudio-app'); ?></th><td id="dsa-view-last-name"><?php echo esc_html($student_data->last_name); ?></td></tr>
                    <tr><th><?php esc_html_e('Email', 'dancestudio-app'); ?></th><td id="dsa-view-email"><a href="mailto:<?php echo esc_attr($student_data->user_email); ?>"><?php echo esc_html($student_data->user_email); ?></a></td></tr>
                    <tr><th><?php esc_html_e('Phone Number', 'dancestudio-app'); ?></th><td id="dsa-view-phone"><?php echo esc_html($phone ?: '—'); ?></td></tr>
                    <tr><th><?php esc_html_e('Street Address', 'dancestudio-app'); ?></th><td id="dsa-view-street"><?php echo esc_html($street); ?></td></tr>
                    <tr><th><?php esc_html_e('Postal Code', 'dancestudio-app'); ?></th><td id="dsa-view-postal-code"><?php echo esc_html($postal_code); ?></td></tr>
                    <tr><th><?php esc_html_e('City / Town', 'dancestudio-app'); ?></th><td id="dsa-view-city"><?php echo esc_html($city); ?></td></tr>
                </table>

                <h3 style="margin-top: 30px;"><?php esc_html_e('Personal Information', 'dancestudio-app'); ?></h3>
                <table class="form-table">
                    <tr><th><?php esc_html_e('Birth Date', 'dancestudio-app'); ?></th><td id="dsa-view-birth-date"><?php echo $birthday ? esc_html(date_i18n(get_option('date_format'), strtotime($birthday))) : '—'; ?></td></tr>
                    <tr><th><?php esc_html_e('Age', 'dancestudio-app'); ?></th><td id="dsa-view-age"><?php echo esc_html($age); ?></td></tr>
                    <tr><th><?php esc_html_e('Dance Partner', 'dancestudio-app'); ?></th>
                        <td>
                            <?php if ($partner_id) : 
                                $partner_data = get_userdata($partner_id);
                                $partner_profile_url = admin_url('admin.php?page=dsa-students-tab&action=view_profile&student_id=' . $partner_id); ?>
                                <a href="<?php echo esc_url($partner_profile_url); ?>"><?php echo esc_html($partner_data->display_name); ?></a>
                            <?php else: echo esc_html__('Not Paired', 'dancestudio-app'); endif; ?>
                        </td>
                    </tr>
                </table>

                <h3 style="margin-top: 30px;"><?php esc_html_e('Discounts', 'dancestudio-app'); ?></h3>
                <table class="form-table">
                     <tr><th><?php esc_html_e('Retiree Discount', 'dancestudio-app'); ?></th><td id="dsa-view-is-retired"><?php echo $is_retired === '1' ? 'Yes' : 'No'; ?></td></tr>
                     <tr><th><?php esc_html_e('Family Discount', 'dancestudio-app'); ?></th><td id="dsa-view-family-discount"><?php echo $has_family_discount === '1' ? 'Yes' : 'No'; ?></td></tr>
                </table>
            </div>
            <div style="flex-basis: 250px;">
                <h3><?php esc_html_e('Actions', 'dancestudio-app'); ?></h3>
                <p><button type="button" id="dsa-edit-profile-details-button" class="button button-primary" data-student-id="<?php echo esc_attr($student_id); ?>"><?php esc_html_e('Edit Details', 'dancestudio-app'); ?></button></p>
                <p><a href="<?php echo esc_url(admin_url('post-new.php?post_type=dsa_private_lesson&student_id=' . $student_id)); ?>" class="button button-secondary"><span class="dashicons dashicons-plus-alt" style="vertical-align: text-bottom;"></span> <?php esc_html_e('Log New Private Lesson', 'dancestudio-app'); ?></a></p>
            </div>
        </div>
        <div id="dsa-edit-student-profile-modal" title="Edit Student Details" style="display:none;">
            <form id="dsa-edit-student-profile-form">
                <input type="hidden" id="dsa_edit_student_id" name="student_id" value="">
                <?php wp_nonce_field( 'dsa_save_student_details_nonce_action', 'dsa_save_student_details_nonce' ); ?>
                <table class="form-table">
                    <tr><th><label>First Name</label></th><td><input type="text" name="first_name" id="dsa_edit_first_name" class="widefat"></td></tr>
                    <tr><th><label>Last Name</label></th><td><input type="text" name="last_name" id="dsa_edit_last_name" class="widefat"></td></tr>
                    <tr><th><label>Email</label></th><td><input type="email" name="email" id="dsa_edit_email" class="widefat"></td></tr>
                    <tr><th><label>Phone Number</label></th><td><input type="tel" name="phone" id="dsa_edit_phone" class="widefat"></td></tr>
                    <tr><th><label>Street Address</label></th><td><input type="text" name="street" id="dsa_edit_street" class="widefat"></td></tr>
                    <tr><th><label>Postal Code</label></th><td><input type="text" name="postal_code" id="dsa_edit_postal_code" class="widefat"></td></tr>
                    <tr><th><label>City / Town</label></th><td><input type="text" name="city" id="dsa_edit_city" class="widefat"></td></tr>
                    <tr><th><label>Birth Date</label></th><td><input type="date" name="birth_date" id="dsa_edit_birth_date" class="widefat"></td></tr>
                    <tr><th>Discounts</th><td>
                        <label><input type="checkbox" name="is_retired" id="dsa_edit_is_retired" value="1"> Retiree</label><br>
                        <label><input type="checkbox" name="family_discount" id="dsa_edit_family_discount" value="1"> Family</label>
                    </td></tr>
                </table>
            </form>
        </div>
        <?php
    }
}

/**
 * Renders the content for the "Enrollment History" tab.
 */
if ( ! function_exists( 'dsa_render_enrollment_history_tab_content' ) ) {
    function dsa_render_enrollment_history_tab_content( $student_data ) {
        $student_id = $student_data->ID;
        $enrollment_records = get_posts([
            'post_type' => 'dsa_enroll_record', 'post_status' => ['publish', 'dropped_out'],
            'author' => $student_id, 'posts_per_page' => -1, 'orderby' => 'date', 'order' => 'DESC',
        ]);
        ?>
        <p>
            <button type="button" class="button button-primary dsa-enroll-modal-button" data-student-id="<?php echo esc_attr($student_id); ?>">
                <span class="dashicons dashicons-groups" style="vertical-align: text-bottom;"></span> <?php esc_html_e('Enroll in New Group', 'dancestudio-app'); ?>
            </button>
        </p>
        <table class="wp-list-table widefat fixed striped" id="dsa-enrollment-history-table">
            <thead><tr><th><?php _e('Group Name');?></th><th><?php _e('Status');?></th><th><?php _e('Enrolled On');?></th><th><?php _e('Dropped Out On');?></th><th><?php _e('Actions');?></th></tr></thead>
            <tbody>
                <?php if ( ! empty( $enrollment_records ) ) : foreach( $enrollment_records as $record ) :
                    $enroll_date = $record->post_date;
                    $dropout_date = get_post_meta($record->ID, '_dsa_dropout_date', true);
                ?>
                <tr data-record-id="<?php echo esc_attr($record->ID); ?>">
                    <td><strong><a href="<?php echo esc_url(get_edit_post_link($record->post_parent)); ?>"><?php echo esc_html(get_the_title($record->post_parent)); ?></a></strong></td>
                    <td><?php echo $record->post_status === 'publish' ? '<span style="color:green;">' . esc_html__('Active', 'dancestudio-app') . '</span>' : '<span style="color:red;">' . esc_html__('Dropped Out', 'dancestudio-app') . '</span>'; ?></td>
                    <td>
                        <span class="dsa-editable-date" data-original-date="<?php echo esc_attr(date('Y-m-d', strtotime($enroll_date))); ?>"><?php echo esc_html(date_i18n(get_option('date_format'), strtotime($enroll_date))); ?></span>
                        <input type="date" class="dsa-date-input" data-date-type="enroll" data-record-id="<?php echo esc_attr($record->ID); ?>" value="<?php echo esc_attr(date('Y-m-d', strtotime($enroll_date))); ?>" style="display:none;">
                    </td>
                    <td>
                        <span class="dsa-editable-date" data-original-date="<?php echo esc_attr($dropout_date ? date('Y-m-d', strtotime($dropout_date)) : ''); ?>"><?php echo $dropout_date ? esc_html(date_i18n(get_option('date_format'), strtotime($dropout_date))) : '—'; ?></span>
                        <input type="date" class="dsa-date-input" data-date-type="dropout" data-record-id="<?php echo esc_attr($record->ID); ?>" value="<?php echo esc_attr($dropout_date ? date('Y-m-d', strtotime($dropout_date)) : ''); ?>" style="display:none;">
                    </td>
                    <td>
                        <?php if ($record->post_status === 'publish') : ?>
                            <button type="button" class="button-link dsa-dropout-button" data-group-id="<?php echo esc_attr($record->post_parent); ?>"><?php _e('Drop Out'); ?></button> |
                        <?php endif; ?>
                        <button type="button" class="button-link-delete dsa-delete-enrollment-button" data-record-id="<?php echo esc_attr($record->ID); ?>"><?php _e('Delete'); ?></button>
                    </td>
                </tr>
                <?php endforeach; else: ?>
                    <tr><td colspan="5"><?php esc_html_e('This student has no enrollment history.', 'dancestudio-app'); ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div id="dsa-enrollment-modal" title="<?php esc_attr_e('Enroll Student in Group', 'dancestudio-app'); ?>" style="display:none;">
            <p><label for="dsa-group-to-enroll">Group:</label><br><select id="dsa-group-to-enroll" style="width:100%;"></select></p>
            <p><label for="dsa-enroll-date">Enrollment Date:</label><br><input type="date" id="dsa-enroll-date" value="<?php echo date('Y-m-d'); ?>"></p>
        </div>
        <div id="dsa-dropout-modal" title="<?php esc_attr_e('Drop Out from Group', 'dancestudio-app'); ?>" style="display:none;">
            <input type="hidden" id="dsa-dropout-group-id" value="">
            <p><?php _e('Please select the date this student is dropping out.', 'dancestudio-app'); ?></p>
            <p><label for="dsa-dropout-date">Dropout Date:</label><br><input type="date" id="dsa-dropout-date" value="<?php echo date('Y-m-d'); ?>"></p>
        </div>
        <?php
    }
}

/**
 * Renders the content for the "Private Lessons" tab.
 */
if ( ! function_exists( 'dsa_render_private_lessons_tab_content' ) ) {
    function dsa_render_private_lessons_tab_content( $student_data ) {
        $student_id = $student_data->ID;
        $lessons = get_posts(['post_type' => 'dsa_private_lesson', 'posts_per_page' => -1, 'meta_query' => ['relation' => 'OR', ['key' => '_dsa_lesson_student1_id', 'value' => $student_id], ['key' => '_dsa_lesson_student2_id', 'value' => $student_id]], 'meta_key' => '_dsa_lesson_date', 'orderby' => 'meta_value', 'order' => 'DESC', ]);
        $log_lesson_url = admin_url('post-new.php?post_type=dsa_private_lesson&student_id=' . $student_id);
        ?>
        <p><a href="<?php echo esc_url($log_lesson_url); ?>" class="button button-primary"><span class="dashicons dashicons-plus-alt" style="vertical-align: text-bottom;"></span> <?php esc_html_e('Log New Private Lesson for this Student', 'dancestudio-app'); ?></a></p>
        <table class="wp-list-table widefat fixed striped">
            <thead><tr><th><?php _e('Lesson Date');?></th><th><?php _e('Lesson Title');?></th><th><?php _e('Teacher');?></th><th><?php _e('Linked Order');?></th></tr></thead>
            <tbody>
            <?php if ( ! empty( $lessons ) ) : foreach( $lessons as $lesson ) :
                $teacher_id = get_post_meta($lesson->ID, '_dsa_lesson_teacher_id', true);
                $order_id = get_post_meta($lesson->ID, '_dsa_lesson_order_id', true);
            ?>
            <tr>
                <td><strong><a href="<?php echo esc_url(get_edit_post_link($lesson->ID)); ?>"><?php echo esc_html(get_post_meta($lesson->ID, '_dsa_lesson_date', true)); ?></a></strong></td>
                <td><?php echo esc_html($lesson->post_title); ?></td>
                <td><?php echo $teacher_id ? esc_html(get_the_author_meta('display_name', $teacher_id)) : '—'; ?></td>
                <td><?php echo $order_id ? '<a href="' . get_edit_post_link($order_id) . '">#' . esc_html($order_id) . '</a>' : '—'; ?></td>
            </tr>
            <?php endforeach; else: ?>
                <tr><td colspan="4"><?php esc_html_e('This student has no private lesson history.', 'dancestudio-app'); ?></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
        <?php
    }
}

/**
 * Renders the content for the "Packages & Orders" tab.
 */
if ( ! function_exists( 'dsa_render_packages_orders_tab_content' ) ) {
    function dsa_render_packages_orders_tab_content( $student_data ) {
        if ( function_exists('dsa_render_order_tracker_table') ) {
            dsa_render_order_tracker_table(['customer_id' => $student_data->ID]);
        } else {
            echo '<p>' . esc_html__('Order tracker function not found.', 'dancestudio-app') . '</p>';
        }
    }
}