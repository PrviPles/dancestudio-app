<?php
/**
 * View: Renders the detailed profile page for a single couple.
 * UPDATED: Adds profile links in title, MP3 uploader/player, Switch Roles button, and other features.
 */
if ( ! defined( 'WPINC' ) ) { die; }

if ( ! function_exists( 'dsa_render_single_couple_details_view' ) ) {
    function dsa_render_single_couple_details_view( $user1_id, $user2_id ) {
        $user1_data = get_userdata($user1_id); 
        $user2_data = get_userdata($user2_id);
        if ( ! $user1_data || ! $user2_data ) { 
            echo '<div class="wrap"><h1>'.esc_html__('Error', 'dancestudio-app').'</h1><p>'.esc_html__('Invalid user ID.', 'dancestudio-app').'</p></div>'; 
            return; 
        }

        $u1_fn = trim($user1_data->first_name.' '.$user1_data->last_name) ?: $user1_data->display_name;
        $u2_fn = trim($user2_data->first_name.' '.$user2_data->last_name) ?: $user2_data->display_name;
        
        $u1_profile_url = admin_url('admin.php?page=dsa-students-tab&action=view_profile&student_id=' . $user1_id);
        $u2_profile_url = admin_url('admin.php?page=dsa-students-tab&action=view_profile&student_id=' . $user2_id);
        
        if ( isset($_GET['message']) ) {
            $message_text = '';
            switch ($_GET['message']) {
                case 'updated': $message_text = __('Couple details have been updated successfully!', 'dancestudio-app'); break;
                case 'archived': $message_text = __('Couple has been archived.', 'dancestudio-app'); break;
                case 'unarchived': $message_text = __('Couple has been restored from the archive.', 'dancestudio-app'); break;
            }
            if ($message_text) echo '<div id="message" class="updated notice is-dismissible"><p>' . esc_html($message_text) . '</p></div>';
        }
        
        $couple_type = get_user_meta($user1_id, '_dsa_couple_type', true) ?: 'wedding';
        $couple_status = get_user_meta($user1_id, '_dsa_couple_status', true) ?: 'active';

        $switch_roles_url = add_query_arg([
            'page'       => 'dsa-couples-tab',
            'action'     => 'view_couple_details',
            'user1_id'   => $user2_id,
            'user2_id'   => $user1_id,
        ], admin_url('admin.php'));
        ?>
        <style>
            .dsa-table-responsive-wrapper { width: 100%; overflow-x: auto; }
            .dsa-responsive-embed { position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; max-width: 100%; }
            .dsa-responsive-embed iframe { position: absolute; top: 0; left: 0; width: 100%; height: 100%; }
        </style>

        <div class="wrap">
            <div style="margin-bottom: 15px;">
                <a href="<?php echo esc_url(admin_url('admin.php?page=dsa-couples-tab')); ?>" class="button">&larr; <?php esc_html_e('Back to All Couples', 'dancestudio-app'); ?></a>
                <a href="<?php echo esc_url(admin_url('admin.php?page=dsa-calendar-tab')); ?>" class="button-secondary" style="margin-left: 10px;"><?php esc_html_e('Go to Calendar', 'dancestudio-app'); ?></a>
            </div>

            <h1>
                <?php esc_html_e('Details for Couple: ', 'dancestudio-app'); ?>
                <a href="<?php echo esc_url($u1_profile_url); ?>"><?php echo esc_html($u1_fn); ?></a> &amp; 
                <a href="<?php echo esc_url($u2_profile_url); ?>"><?php echo esc_html($u2_fn); ?></a>
            </h1>

            <div id="poststuff">
                <div id="post-body" class="metabox-holder columns-2">
                    <div id="post-body-content">
                        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                            <input type="hidden" name="action" value="dsa_update_couple_details">
                            <input type="hidden" name="user1_id" value="<?php echo esc_attr($user1_id); ?>">
                            <input type="hidden" name="user2_id" value="<?php echo esc_attr($user2_id); ?>">
                            <?php wp_nonce_field('dsa_couple_details_action', 'dsa_couple_details_nonce'); ?>

                            <div class="postbox">
                                <h2 class="hndle"><span><?php _e('Couple Information', 'dancestudio-app'); ?></span></h2>
                                <div class="inside">
                                    <table class="form-table">
                                        <tr>
                                            <th><label><?php _e('Couple Status', 'dancestudio-app'); ?></label></th>
                                            <td><strong style="color: <?php echo $couple_status === 'active' ? 'green' : 'red'; ?>; padding: 5px 8px; background: #f0f0f1; border-radius: 4px;"><?php echo esc_html(ucfirst($couple_status)); ?></strong></td>
                                        </tr>
                                        <tr>
                                            <th><label for="dsa_couple_type"><?php _e('Couple Type', 'dancestudio-app'); ?></label></th>
                                            <td>
                                                <select name="dsa_couple_type" id="dsa_couple_type">
                                                    <option value="wedding" <?php selected($couple_type, 'wedding'); ?>><?php _e('Wedding', 'dancestudio-app'); ?></option>
                                                    <option value="recreation" <?php selected($couple_type, 'recreation'); ?>><?php _e('Recreation', 'dancestudio-app'); ?></option>
                                                    <option value="competitive" <?php selected($couple_type, 'competitive'); ?>><?php _e('Competitive', 'dancestudio-app'); ?></option>
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th><label for="dsa_pairing_date"><?php _e('Paired On Date', 'dancestudio-app'); ?></label></th>
                                            <td>
                                                <?php $pairing_date = get_user_meta($user1_id, '_dsa_pairing_date', true); ?>
                                                <input type="date" id="dsa_pairing_date" name="dsa_pairing_date" value="<?php echo esc_attr( date('Y-m-d', strtotime($pairing_date)) ); ?>">
                                            </td>
                                        </tr>
                                    </table>
                                    <hr>
                                    <div class="submit" style="display: flex; gap: 10px; padding: 0; align-items: center;">
                                         <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php esc_attr_e('Save Changes', 'dancestudio-app'); ?>">
                                         <a href="<?php echo esc_url($switch_roles_url); ?>" class="button button-secondary"><?php esc_html_e('Switch Roles', 'dancestudio-app'); ?></a>
                                    </div>
                                    <div style="float: right; margin-top: -40px;">
                                        <?php if ($couple_status === 'active') : ?>
                                            <button type="submit" name="submit_archive_couple" class="button button-link-delete" onclick="return confirm('<?php esc_attr_e('Are you sure you want to archive this couple?', 'dancestudio-app'); ?>');"><?php esc_html_e('Archive Couple', 'dancestudio-app'); ?></button>
                                        <?php else : ?>
                                            <button type="submit" name="submit_unarchive_couple" class="button"><?php esc_html_e('Restore from Archive', 'dancestudio-app'); ?></button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        
                            <?php if ($couple_type === 'wedding') : ?>
                            <div class="postbox">
                                <h2 class="hndle"><span><?php _e('Wedding & Song Details', 'dancestudio-app'); ?></span></h2>
                                <div class="inside">
                                    <?php
                                    $wedding_date_str = get_user_meta($user1_id, 'dsa_wedding_date', true);
                                    $songs = get_user_meta($user1_id, '_dsa_couple_songs', true);
                                    if (empty($songs) || !is_array($songs)) $songs = [['name' => '', 'url' => '']];
                                    ?>
                                    <table class="form-table">
                                        <tr>
                                            <th><label for="dsa_wedding_date"><?php _e('Wedding Date', 'dancestudio-app'); ?></label></th>
                                            <td><input type="date" id="dsa_wedding_date" name="dsa_wedding_date" value="<?php echo esc_attr($wedding_date_str); ?>"></td>
                                        </tr>
                                    </table>
                                    <hr>
                                    <h4><?php _e('Wedding Songs', 'dancestudio-app'); ?></h4>
                                    <div id="dsa-songs-repeater-wrapper">
                                        <?php foreach ($songs as $index => $song) : ?>
                                        <div class="dsa-song-entry" style="padding: 15px; border: 1px solid #ddd; margin-bottom: 10px; background: #f9f9f9;">
                                            <p><label>Song Name</label><input type="text" name="dsa_songs[<?php echo $index; ?>][name]" value="<?php echo esc_attr($song['name'] ?? ''); ?>" class="widefat"></p>
                                            <p><label>Song File (MP3)</label>
                                                <input type="text" name="dsa_songs[<?php echo $index; ?>][url]" value="<?php echo esc_attr($song['url'] ?? ''); ?>" class="widefat dsa-song-url-field">
                                                <button type="button" class="button dsa-upload-song-button" style="margin-top: 5px;">Upload / Select Song</button>
                                                <button type="button" class="button button-secondary dsa-remove-song-button" style="margin-top: 5px; <?php if (empty($song['url'])) echo 'display:none;'; ?>">Remove</button>
                                            </p>
                                            <button type="button" class="button button-link-delete dsa-delete-song-button"><?php _e('Delete Song Entry'); ?></button>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                    <button type="button" id="dsa-add-song-button" class="button button-secondary"><?php _e('+ Add Another Song', 'dancestudio-app'); ?></button>
                                </div>
                            </div>
                            <?php endif; ?>
                        </form>
                        
                        <?php if ($couple_type === 'wedding') : 
                            $songs_to_play = get_user_meta($user1_id, '_dsa_couple_songs', true);
                            if ( ! empty($songs_to_play) && is_array($songs_to_play) ) :
                                $has_player = false;
                                foreach ($songs_to_play as $song) { if ( !empty($song['url']) ) { $has_player = true; break; } }
                                
                                if ($has_player) : ?>
                                <div class="postbox">
                                    <h2 class="hndle"><span><?php _e('Song Players', 'dancestudio-app'); ?></span></h2>
                                    <div class="inside">
                                        <?php
                                        foreach ($songs_to_play as $song) {
                                            if ( ! empty($song['url']) && filter_var($song['url'], FILTER_VALIDATE_URL) ) {
                                                $song_name = !empty($song['name']) ? $song['name'] : 'Song Player';
                                                echo '<h4>' . esc_html($song_name) . '</h4>';
                                                if ( substr( strtolower($song['url']), -4 ) === '.mp3' ) {
                                                    echo '<audio controls src="' . esc_url($song['url']) . '" style="width: 100%; max-width: 400px;"></audio>';
                                                } else {
                                                    $embed_code = wp_oembed_get($song['url']);
                                                    if ( $embed_code ) {
                                                        echo '<div class="dsa-responsive-embed">' . $embed_code . '</div>';
                                                    }
                                                }
                                                echo '<hr style="margin-top:20px;">';
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                                <?php endif;
                            endif;
                        endif; ?>

                        <div class="postbox">
                            <h2 class="hndle"><span><?php _e('Knowledge Base', 'dancestudio-app'); ?></span></h2>
                            <div class="inside">
                                <?php
                                $leader_figures = get_user_meta($user1_id, '_dsa_known_figures', true) ?: [];
                                $follower_figures = get_user_meta($user2_id, '_dsa_known_figures', true) ?: [];
                                $couple_figures = array_intersect($leader_figures, $follower_figures);
                                $leader_only_figures = array_diff($leader_figures, $follower_figures);
                                $follower_only_figures = array_diff($follower_figures, $leader_figures);
                                ?>
                                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
                                    <div class="knowledge-column">
                                        <h4><?php printf(esc_html__('Leader Only (%s)', 'dancestudio-app'), esc_html($user1_data->first_name)); ?></h4>
                                        <hr>
                                        <?php if(function_exists('dsa_display_grouped_figures_list')) dsa_display_grouped_figures_list($leader_only_figures); ?>
                                    </div>
                                    <div class="knowledge-column">
                                        <h4><?php printf(esc_html__('Follower Only (%s)', 'dancestudio-app'), esc_html($user2_data->first_name)); ?></h4>
                                        <hr>
                                        <?php if(function_exists('dsa_display_grouped_figures_list')) dsa_display_grouped_figures_list($follower_only_figures); ?>
                                    </div>
                                    <div class="knowledge-column">
                                        <h4 style="color: #2271b1;"><?php esc_html_e('Couple (Shared)', 'dancestudio-app'); ?></h4>
                                        <hr>
                                        <?php if(function_exists('dsa_display_grouped_figures_list')) dsa_display_grouped_figures_list($couple_figures); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php if ($couple_type !== 'competitive') : ?>
                        <div class="postbox">
                            <h2 class="hndle"><span><?php _e('Lesson Package Tracker', 'dancestudio-app'); ?></span></h2>
                            <div class="inside">
                                <div class="dsa-table-responsive-wrapper">
                                    <?php if(function_exists('dsa_render_order_tracker_table')) dsa_render_order_tracker_table(['customer_id' => [$user1_id, $user2_id]]); ?>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>

                        <div class="postbox">
                            <h2 class="hndle"><span><?php _e('Private Lesson History', 'dancestudio-app'); ?></span></h2>
                            <div class="inside">
                                <p>
                                    <button type="button" id="dsa-add-lesson-for-couple-button" class="button button-primary" data-user1-id="<?php echo esc_attr($user1_id); ?>" data-user2-id="<?php echo esc_attr($user2_id); ?>"><?php _e('Add Private Lesson for Couple', 'dancestudio-app'); ?></button>
                                </p>
                                <?php
                                $lesson_args = [
                                    'post_type' => 'dsa_private_lesson', 'posts_per_page' => -1,
                                    'meta_query' => ['relation' => 'OR', ['key' => '_dsa_lesson_student1_id', 'value' => $user1_id], ['key' => '_dsa_lesson_student1_id', 'value' => $user2_id], ['key' => '_dsa_lesson_student2_id', 'value' => $user1_id], ['key' => '_dsa_lesson_student2_id', 'value' => $user2_id], ],
                                    'meta_key' => '_dsa_lesson_date', 'orderby' => 'meta_value', 'order' => 'DESC',
                                ];
                                $couple_lessons = get_posts($lesson_args);
                                ?>
                                <div class="dsa-table-responsive-wrapper">
                                    <table class="wp-list-table widefat fixed striped">
                                        <thead><tr><th><?php _e('Lesson Date', 'dancestudio-app'); ?></th><th><?php _e('Lesson Title', 'dancestudio-app'); ?></th><th><?php _e('Notes', 'dancestudio-app'); ?></th><th><?php _e('Figures Practiced', 'dancestudio-app'); ?></th><th><?php _e('Teacher', 'dancestudio-app'); ?></th><th><?php _e('Actions', 'dancestudio-app'); ?></th></tr></thead>
                                        <tbody>
                                            <?php if ( ! empty( $couple_lessons ) ) : ?>
                                                <?php foreach ( $couple_lessons as $lesson ) : 
                                                    $figure_ids = get_post_meta($lesson->ID, '_dsa_practiced_figure_ids', true);
                                                    $figure_names = [];
                                                    if (!empty($figure_ids) && is_array($figure_ids)) { foreach ($figure_ids as $figure_id) { if ($figure_title = get_the_title($figure_id)) { $figure_names[] = $figure_title; } } }
                                                ?>
                                                    <tr>
                                                        <td><?php echo esc_html( get_post_meta( $lesson->ID, '_dsa_lesson_date', true ) ); ?></td>
                                                        <td><?php echo esc_html( $lesson->post_title ); ?></td>
                                                        <td><?php echo esc_html( wp_trim_words( $lesson->post_content, 10, '...' ) ); ?></td>
                                                        <td><?php echo !empty($figure_names) ? esc_html(implode(', ', $figure_names)) : '—'; ?></td>
                                                        <td><?php echo esc_html( get_the_author_meta( 'display_name', get_post_meta( $lesson->ID, '_dsa_lesson_teacher_id', true ) ) ); ?></td>
                                                        <td><a href="<?php echo get_edit_post_link( $lesson->ID ); ?>" class="button button-small"><?php _e('View/Edit'); ?></a></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            <?php else : ?>
                                                <tr><td colspan="6"><?php esc_html_e('No private lessons found for this couple.', 'dancestudio-app'); ?></td></tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div id="dsa-add-lesson-modal" style="display:none;" title="<?php esc_attr_e('Add Private Lesson for Couple', 'dancestudio-app'); ?>">
            <form id="dsa-add-lesson-modal-form">
                <table class="form-table">
                    <tr><th><label for="dsa_modal_lesson_title"><?php _e('Lesson Title', 'dancestudio-app'); ?></label></th><td><input type="text" name="dsa_lesson_title" id="dsa_modal_lesson_title" class="widefat" value="Private Lesson"></td></tr>
                    <tr><th><label for="dsa_modal_lesson_date"><?php _e('Date', 'dancestudio-app'); ?></label></th><td><input type="date" name="dsa_lesson_date" id="dsa_modal_lesson_date" value="<?php echo date('Y-m-d'); ?>"></td></tr>
                    <tr><th><label for="dsa_modal_lesson_start_time"><?php _e('Start Time', 'dancestudio-app'); ?></label></th><td><input type="time" name="dsa_lesson_start_time" id="dsa_modal_lesson_start_time"></td></tr>
                    <tr><th><label for="dsa_modal_lesson_teacher_id"><?php _e('Teacher', 'dancestudio-app'); ?></label></th><td>
                        <?php wp_dropdown_users(['name' => 'dsa_lesson_teacher_id', 'id' => 'dsa_modal_lesson_teacher_id', 'show_option_none' => __('-- Select Teacher --', 'dancestudio-app'), 'role__in' => ['teacher', 'studio_manager', 'administrator'], 'show_fullname' => true]); ?>
                    </td></tr>
                </table>
            </form>
        </div>
        
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            var wrapper = $('#dsa-songs-repeater-wrapper');
            var mediaUploader;
            $('#dsa-add-song-button').on('click', function(e) {
                e.preventDefault();
                var newIndex = wrapper.find('.dsa-song-entry').length;
                var newField = `
                <div class="dsa-song-entry" style="padding: 15px; border: 1px solid #ddd; margin-bottom: 10px; background: #f9f9f9;">
                    <p><label>Song Name</label><input type="text" name="dsa_songs[${newIndex}][name]" value="" class="widefat"></p>
                    <p><label>Song File (MP3)</label>
                        <input type="text" name="dsa_songs[${newIndex}][url]" value="" class="widefat dsa-song-url-field">
                        <button type="button" class="button dsa-upload-song-button" style="margin-top: 5px;">Upload / Select Song</button>
                        <button type="button" class="button button-secondary dsa-remove-song-button" style="margin-top: 5px; display:none;">Remove</button>
                    </p>
                    <button type="button" class="button button-link-delete dsa-delete-song-button">Delete Song Entry</button>
                </div>`;
                wrapper.append(newField);
            });
            wrapper.on('click', '.dsa-delete-song-button', function(e) {
                e.preventDefault();
                if (wrapper.find('.dsa-song-entry').length > 1) {
                    $(this).closest('.dsa-song-entry').remove();
                } else {
                    alert('You must have at least one song entry.');
                    $(this).closest('.dsa-song-entry').find('input').val('');
                }
            });
            wrapper.on('click', '.dsa-upload-song-button', function(e) {
                e.preventDefault();
                var button = $(this);
                mediaUploader = wp.media({
                    title: 'Select Song File',
                    button: { text: 'Use this song' },
                    library: { type: 'audio' },
                    multiple: false
                });
                mediaUploader.on('select', function() {
                    var attachment = mediaUploader.state().get('selection').first().toJSON();
                    var urlField = button.siblings('.dsa-song-url-field');
                    urlField.val(attachment.url);
                    button.siblings('.dsa-remove-song-button').show();
                });
                mediaUploader.open();
            });
            wrapper.on('click', '.dsa-remove-song-button', function(e) {
                e.preventDefault();
                var button = $(this);
                button.siblings('.dsa-song-url-field').val('');
                button.hide();
            });
        });
        </script>
        <?php
    }
}