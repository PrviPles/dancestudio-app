<?php
/**
 * View: Renders the list of all Dance Groups.
 * UPGRADED: Added data-label attributes for responsiveness.
 */

if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * Renders the list of all Dance Groups.
 */
function dsa_render_all_groups_list() {
    ?>
    <div class="wrap">
        <h1 class="wp-heading-inline"><?php esc_html_e( 'Dance Groups', 'dancestudio-app' ); ?></h1>
        <a href="<?php echo admin_url( 'post-new.php?post_type=dsa_group' ); ?>" class="page-title-action"><?php esc_html_e( 'Add New Group', 'dancestudio-app' ); ?></a>
        <hr class="wp-header-end">

        <p><?php esc_html_e( 'This is the central place to manage your dance groups. Click "Manage" on any group to view its detailed profile, statistics, and student roster.', 'dancestudio-app' ); ?></p>

        <table class="wp-list-table widefat fixed striped posts">
            <thead>
                <tr>
                    <th scope="col"><?php esc_html_e('Group Name', 'dancestudio-app'); ?></th>
                    <th scope="col"><?php esc_html_e('Enrolled Students', 'dancestudio-app'); ?></th>
                    <th scope="col"><?php esc_html_e('Primary Teacher', 'dancestudio-app'); ?></th>
                    <th scope="col"><?php esc_html_e('Actions', 'dancestudio-app'); ?></th>
                </tr>
            </thead>
            <tbody id="the-list">
                <?php
                $groups_query = new WP_Query([
                    'post_type'      => 'dsa_group',
                    'posts_per_page' => -1,
                    'orderby'        => 'title',
                    'order'          => 'ASC',
                ]);

                if ( $groups_query->have_posts() ) :
                    while ( $groups_query->have_posts() ) : $groups_query->the_post();
                        $group_id = get_the_ID();
                        
                        $enrollments = get_posts([ 'post_type' => 'dsa_enroll_record', 'post_status' => 'publish', 'post_parent' => $group_id, 'fields' => 'ids' ]);
                        $student_count = count($enrollments);

                        $teacher_id = get_post_meta($group_id, '_dsa_primary_teacher_id', true);
                        $teacher_name = $teacher_id ? get_the_author_meta('display_name', $teacher_id) : '—';
                        
                        $manage_link = admin_url('admin.php?page=dsa-groups-tab&action=view_group&group_id=' . $group_id);
                        ?>
                        <tr id="post-<?php echo esc_attr($group_id); ?>">
                            <td data-colname="<?php esc_attr_e('Group Name', 'dancestudio-app'); ?>">
                                <strong><a class="row-title" href="<?php echo esc_url(get_edit_post_link($group_id)); ?>"><?php the_title(); ?></a></strong>
                            </td>
                            <td data-colname="<?php esc_attr_e('Enrolled Students', 'dancestudio-app'); ?>"><?php echo esc_html($student_count); ?></td>
                            <td data-colname="<?php esc_attr_e('Primary Teacher', 'dancestudio-app'); ?>"><?php echo esc_html($teacher_name); ?></td>
                            <td data-colname="<?php esc_attr_e('Actions', 'dancestudio-app'); ?>"><a href="<?php echo esc_url($manage_link); ?>" class="button button-secondary"><?php esc_html_e('Manage', 'dancestudio-app'); ?></a></td>
                        </tr>
                        <?php
                    endwhile;
                    wp_reset_postdata();
                else: ?>
                    <tr class="no-items"><td class="colspanchange" colspan="4"><?php esc_html_e('No dance groups have been created yet.', 'dancestudio-app'); ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php
}