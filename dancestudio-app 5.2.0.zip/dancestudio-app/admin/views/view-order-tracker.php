<?php
/**
 * View: Renders the Order Tracker report page and the reusable order table.
 * UPDATED: The table function now accepts arguments to show all orders for a specific customer.
 *
 * @package DanceStudioApp
 */

if ( ! defined( 'WPINC' ) ) {
    die;
}

if ( ! function_exists( 'dsa_render_order_tracker_page' ) ) {
    function dsa_render_order_tracker_page() {
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Order & Lesson Package Tracker', 'dancestudio-app' ); ?></h1>
            <p><?php esc_html_e( 'This report shows all paid lesson packages and tracks how many lessons have been used.', 'dancestudio-app' ); ?></p>
            
            <div class="dsa-table-responsive-wrapper">
            <?php 
            if ( function_exists('dsa_render_order_tracker_table') ) {
                dsa_render_order_tracker_table();
            }
            ?>
            </div>

        </div>
        <?php
    }
}

/**
 * Renders a table of WooCommerce orders.
 * Can be filtered by customer and can show all orders or only lesson packages.
 *
 * @param array $args Arguments to filter the orders.
 */
if ( ! function_exists('dsa_render_order_tracker_table') ) {
    function dsa_render_order_tracker_table($args = []) {
        if (!class_exists('WooCommerce')) {
            echo '<p><em>' . esc_html__('WooCommerce is not active. This feature is unavailable.', 'dancestudio-app') . '</em></p>';
            return;
        }

        $show_all = isset($args['show_all']) ? $args['show_all'] : false;

        $query_args = [
            'limit'   => -1,
            'status'  => ['processing', 'completed'],
            'orderby' => 'date',
            'order'   => 'DESC',
        ];

        if (!empty($args['customer_id'])) {
            $query_args['customer'] = $args['customer_id'];
        }

        $orders_query = new WC_Order_Query($query_args);
        $orders = $orders_query->get_orders();
        ?>
        <table class="wp-list-table widefat fixed striped posts">
            <thead>
                <tr>
                    <th style="width:80px;"><?php esc_html_e('Order', 'dancestudio-app'); ?></th>
                    <th><?php esc_html_e('Product(s) Purchased', 'dancestudio-app'); ?></th>
                    <?php if (!$show_all) : // Only show these columns for the main report ?>
                        <th style="width:150px;"><?php esc_html_e('Lessons Used', 'dancestudio-app'); ?></th>
                        <th style="width:200px;"><?php esc_html_e('Progress', 'dancestudio-app'); ?></th>
                    <?php endif; ?>
                    <th><?php esc_html_e('Total', 'dancestudio-app'); ?></th>
                    <th><?php esc_html_e('Order Date', 'dancestudio-app'); ?></th>
                </tr>
            </thead>
            <tbody id="the-list">
            <?php
            $found_orders = false;
            if (!empty($orders)) {
                foreach ($orders as $order) {
                    $order_id = $order->get_id();
                    $items = $order->get_items();
                    $is_lesson_package = false;
                    $product_names = [];

                    foreach ($items as $item) {
                        $product_id = $item->get_product_id();
                        $product_names[] = $item->get_name();
                        if (has_term('lesson-packages', 'product_cat', $product_id)) {
                            $is_lesson_package = true;
                        }
                    }

                    if (!$show_all && !$is_lesson_package) {
                        continue; // Skip if we're on the main report and this is not a lesson package
                    }

                    $found_orders = true;
                    ?>
                    <tr>
                        <td><a href="<?php echo esc_url(get_edit_post_link($order_id)); ?>" target="_blank"><strong>#<?php echo esc_html($order_id); ?></strong></a></td>
                        <td><?php echo esc_html(implode(', ', $product_names)); ?></td>
                        
                        <?php if (!$show_all) :
                            $lessons_in_package = (int)get_post_meta($product_id, '_dsa_lessons_in_package', true);
                            $lessons_used_query = new WP_Query(['post_type' => 'dsa_private_lesson', 'posts_per_page' => -1, 'meta_key' => '_dsa_lesson_order_id', 'meta_value' => $order_id, 'fields' => 'ids']);
                            $lessons_used_count = $lessons_used_query->found_posts;
                            $progress_percent = ($lessons_in_package > 0) ? ($lessons_used_count / $lessons_in_package) * 100 : 0;
                        ?>
                            <td><strong><?php echo esc_html($lessons_used_count); ?> / <?php echo esc_html($lessons_in_package); ?></strong></td>
                            <td><div style="background-color:#e0e0e0;border-radius:4px;overflow:hidden;"><div style="width:<?php echo esc_attr($progress_percent);?>%;background-color:#4caf50;padding:4px;color:white;text-align:center;font-size:12px;"><?php echo round($progress_percent);?>%</div></div></td>
                        <?php endif; ?>

                        <td><?php echo wp_kses_post($order->get_formatted_order_total()); ?></td>
                        <td><?php echo esc_html($order->get_date_created()->date_i18n('j. F Y.')); ?></td>
                    </tr>
                <?php }
            }
            
            if (!$found_orders) {
                $message = $show_all ? __('This user has no order history.', 'dancestudio-app') : __('No paid orders found for products in the "Lesson Packages" category.', 'dancestudio-app');
                echo '<tr class="no-items"><td class="colspanchange" colspan="' . ($show_all ? 4 : 6) . '">' . esc_html($message) . '</td></tr>';
            }
            ?>
            </tbody>
        </table>
        <?php 
    }
}